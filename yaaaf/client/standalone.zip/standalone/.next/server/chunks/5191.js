"use strict";exports.id=5191,exports.ids=[5191,1706,3018],exports.modules={55283:(e,t,a)=>{a.r(t),a.d(t,{MessageList:()=>r});var s=a(19652),i=a(8141),n=a(23018);function r({messages:e,showTimeStamps:t=!0,isTyping:a=!1,messageOptions:r,onArtifactClick:l,streamStatus:d}){return(0,s.jsxs)("div",{className:"space-y-4 overflow-visible",children:[e.map((a,n)=>{let c="function"==typeof r?r(a):r,o="assistant"===a.role&&n===e.length-1,m=o&&d?.is_active;return s.jsx(i.ChatMessage,{showTimeStamp:t,...a,...c,onArtifactClick:l,streamStatus:m?d:void 0,isLastMessage:o},n)}),a&&s.jsx(n.TypingIndicator,{streamStatus:d})]})}},23018:(e,t,a)=>{a.r(t),a.d(t,{TypingIndicator:()=>n});var s=a(19652),i=a(34630);function n({streamStatus:e}){return s.jsx("div",{className:"justify-left flex space-x-1",children:s.jsx("div",{className:"rounded-lg bg-muted p-3",children:(0,s.jsxs)("div",{className:"flex items-center gap-2 text-muted-foreground",children:[s.jsx(i.Z,{className:"h-4 w-4 animate-spin"}),s.jsx("span",{className:"text-xs",children:e?.is_active&&e?.current_agent?"orchestrator"===e.current_agent?"Planning...":`Running ${e.current_agent}...`:"Thinking..."}),e?.is_active&&e?.goal&&(0,s.jsxs)("span",{className:"text-xs opacity-70",children:["•"," ",e.goal.length>50?e.goal.substring(0,50)+"...":e.goal]})]})})})}},40956:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]])},85640:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},64842:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},10106:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]])},34630:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},58671:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(13252).Z)("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]])}};