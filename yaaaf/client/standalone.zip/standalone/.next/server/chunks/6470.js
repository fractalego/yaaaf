"use strict";exports.id=6470,exports.ids=[6470,4769,9934],exports.modules={42206:(e,a,t)=>{t.r(a),t.d(a,{MessageList:()=>d});var i=t(41692),s=t(67230),l=t(99934);function d({messages:e,showTimeStamps:a=!0,isTyping:t=!1,messageOptions:d,onArtifactClick:n}){return(0,i.jsxs)("div",{className:"space-y-4 overflow-visible",children:[e.map((e,t)=>{let l="function"==typeof d?d(e):d;return i.jsx(s.ChatMessage,{showTimeStamp:a,...e,...l,onArtifactClick:n},t)}),t&&i.jsx(l.TypingIndicator,{})]})}},99934:(e,a,t)=>{t.r(a),t.d(a,{TypingIndicator:()=>l});var i=t(41692),s=t(95482);function l(){return i.jsx("div",{className:"justify-left flex space-x-1",children:i.jsx("div",{className:"rounded-lg bg-muted p-3",children:(0,i.jsxs)("div",{className:"flex -space-x-2.5",children:[i.jsx(s.Z,{className:"h-5 w-5 animate-typing-dot-bounce"}),i.jsx(s.Z,{className:"h-5 w-5 animate-typing-dot-bounce [animation-delay:90ms]"}),i.jsx(s.Z,{className:"h-5 w-5 animate-typing-dot-bounce [animation-delay:180ms]"})]})})})}},23020:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]])},75323:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},96475:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},95482:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("Dot",[["circle",{cx:"12.1",cy:"12.1",r:"1",key:"18d7e5"}]])},83995:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]])},48990:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},61217:(e,a,t)=>{t.d(a,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,t(80644).Z)("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]])}};