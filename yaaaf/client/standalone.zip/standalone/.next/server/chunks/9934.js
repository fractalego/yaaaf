"use strict";exports.id=9934,exports.ids=[9934],exports.modules={99934:(e,s,a)=>{a.r(s),a.d(s,{TypingIndicator:()=>n});var i=a(41692),t=a(95482);function n(){return i.jsx("div",{className:"justify-left flex space-x-1",children:i.jsx("div",{className:"rounded-lg bg-muted p-3",children:(0,i.jsxs)("div",{className:"flex -space-x-2.5",children:[i.jsx(t.Z,{className:"h-5 w-5 animate-typing-dot-bounce"}),i.jsx(t.Z,{className:"h-5 w-5 animate-typing-dot-bounce [animation-delay:90ms]"}),i.jsx(t.Z,{className:"h-5 w-5 animate-typing-dot-bounce [animation-delay:180ms]"})]})})})}},95482:(e,s,a)=>{a.d(s,{Z:()=>i});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,a(80644).Z)("Dot",[["circle",{cx:"12.1",cy:"12.1",r:"1",key:"18d7e5"}]])}};