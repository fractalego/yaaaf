"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[357],{78743:(e,t,n)=>{n.d(t,{M:()=>k});var r=n(90016),l=n(66666),a=n(50784),h=n(2851),i=n(32591);class s extends l.Component{getSnapshotBeforeUpdate(e){let t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){let e=this.props.sizeRef.current;e.height=t.offsetHeight||0,e.width=t.offsetWidth||0,e.top=t.offsetTop,e.left=t.offsetLeft}return null}componentDidUpdate(){}render(){return this.props.children}}function d(e){let{children:t,isPresent:n}=e,a=(0,l.useId)(),h=(0,l.useRef)(null),d=(0,l.useRef)({width:0,height:0,top:0,left:0}),{nonce:p}=(0,l.useContext)(i._);return(0,l.useInsertionEffect)(()=>{let{width:e,height:t,top:r,left:l}=d.current;if(n||!h.current||!e||!t)return;h.current.dataset.motionPopId=a;let i=document.createElement("style");return p&&(i.nonce=p),document.head.appendChild(i),i.sheet&&i.sheet.insertRule('\n          [data-motion-pop-id="'.concat(a,'"] {\n            position: absolute !important;\n            width: ').concat(e,"px !important;\n            height: ").concat(t,"px !important;\n            top: ").concat(r,"px !important;\n            left: ").concat(l,"px !important;\n          }\n        ")),()=>{document.head.removeChild(i)}},[n]),(0,r.jsx)(s,{isPresent:n,childRef:h,sizeRef:d,children:l.cloneElement(t,{ref:h})})}let p=e=>{let{children:t,initial:n,isPresent:i,onExitComplete:s,custom:p,presenceAffectsLayout:c,mode:u}=e,y=(0,h.h)(o),f=(0,l.useId)(),m=(0,l.useCallback)(e=>{for(let t of(y.set(e,!0),y.values()))if(!t)return;s&&s()},[y,s]),k=(0,l.useMemo)(()=>({id:f,initial:n,isPresent:i,custom:p,onExitComplete:m,register:e=>(y.set(e,!1),()=>y.delete(e))}),c?[Math.random(),m]:[i,m]);return(0,l.useMemo)(()=>{y.forEach((e,t)=>y.set(t,!1))},[i]),l.useEffect(()=>{i||y.size||!s||s()},[i]),"popLayout"===u&&(t=(0,r.jsx)(d,{isPresent:i,children:t})),(0,r.jsx)(a.O.Provider,{value:k,children:t})};function o(){return new Map}var c=n(77936),u=n(38771);let y=e=>e.key||"";function f(e){let t=[];return l.Children.forEach(e,e=>{(0,l.isValidElement)(e)&&t.push(e)}),t}var m=n(91935);let k=e=>{let{children:t,exitBeforeEnter:n,custom:a,initial:i=!0,onExitComplete:s,presenceAffectsLayout:d=!0,mode:o="sync"}=e;(0,u.k)(!n,"Replace exitBeforeEnter with mode='wait'");let k=(0,l.useMemo)(()=>f(t),[t]),x=k.map(y),M=(0,l.useRef)(!0),Z=(0,l.useRef)(k),v=(0,h.h)(()=>new Map),[g,w]=(0,l.useState)(k),[C,b]=(0,l.useState)(k);(0,m.L)(()=>{M.current=!1,Z.current=k;for(let e=0;e<C.length;e++){let t=y(C[e]);x.includes(t)?v.delete(t):!0!==v.get(t)&&v.set(t,!1)}},[C,x.length,x.join("-")]);let E=[];if(k!==g){let e=[...k];for(let t=0;t<C.length;t++){let n=C[t],r=y(n);x.includes(r)||(e.splice(t,0,n),E.push(n))}"wait"===o&&E.length&&(e=E),b(f(e)),w(k);return}let{forceRender:H}=(0,l.useContext)(c.p);return(0,r.jsx)(r.Fragment,{children:C.map(e=>{let t=y(e),n=k===C||x.includes(t);return(0,r.jsx)(p,{isPresent:n,initial:(!M.current||!!i)&&void 0,custom:n?void 0:a,presenceAffectsLayout:d,mode:o,onExitComplete:n?void 0:()=>{if(!v.has(t))return;v.set(t,!0);let e=!0;v.forEach(t=>{t||(e=!1)}),e&&(null==H||H(),b(Z.current),s&&s())},children:e},t)})})}},16776:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ArrowUp",[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]])},79816:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},49393:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]])},1164:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]])},81027:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("FileSpreadsheet",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]])},75873:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},10170:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Paperclip",[["path",{d:"m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48",key:"1u3ebp"}]])},41853:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Square",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]])},3177:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ThumbsDown",[["path",{d:"M17 14V2",key:"8ymqnk"}],["path",{d:"M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z",key:"s6e0r"}]])},25006:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ThumbsUp",[["path",{d:"M7 10v12",key:"1qc93n"}],["path",{d:"M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z",key:"y3tblf"}]])},92497:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Upload",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]])}}]);