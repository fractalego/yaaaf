"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[703,6123],{48173:(e,a,t)=>{t.r(a),t.d(a,{default:()=>l});var n=t(1917),i=t(95771);function l(){return(0,n.jsxs)("div",{className:"w-full space-y-4",children:[(0,n.jsx)(i.ChatMessage,{id:"1",role:"user",content:"Slide animation",animation:"slide"}),(0,n.jsx)(i.ChatMessage,{id:"2",role:"assistant",content:"Scale animation",animation:"scale"}),(0,n.jsx)(i.ChatMessage,{id:"3",role:"user",content:"Fade animation",animation:"fade"}),(0,n.jsx)(i.ChatMessage,{id:"4",role:"assistant",content:"No animation",animation:"none"})]})}},94704:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]])},15480:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},45527:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},18576:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]])},40451:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},39636:(e,a,t)=>{t.d(a,{Z:()=>n});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,t(88867).Z)("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]])}}]);