"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8386],{38386:(s,a,e)=>{e.r(a),e.d(a,{default:()=>r});var t=e(90016),h=e(25006),n=e(3177),c=e(68107),i=e(43769),l=e(5503);function r(){return(0,t.jsx)("div",{className:"w-full space-y-4",children:(0,t.jsx)(i.ChatMessage,{id:"1",role:"assistant",content:"Here's a message with actions",actions:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"border-r pr-1",children:(0,t.jsx)(l.CopyButton,{content:"Here's a message with actions",copyMessage:"Copied response to clipboard!"})}),(0,t.jsx)(c.z,{size:"icon",variant:"ghost",className:"h-6 w-6",children:(0,t.jsx)(h.Z,{className:"h-4 w-4"})}),(0,t.jsx)(c.z,{size:"icon",variant:"ghost",className:"h-6 w-6",children:(0,t.jsx)(n.Z,{className:"h-4 w-4"})})]})})})}},3177:(s,a,e)=>{e.d(a,{Z:()=>t});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let t=(0,e(38861).Z)("ThumbsDown",[["path",{d:"M17 14V2",key:"8ymqnk"}],["path",{d:"M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z",key:"s6e0r"}]])},25006:(s,a,e)=>{e.d(a,{Z:()=>t});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let t=(0,e(38861).Z)("ThumbsUp",[["path",{d:"M7 10v12",key:"1qc93n"}],["path",{d:"M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z",key:"y3tblf"}]])}}]);