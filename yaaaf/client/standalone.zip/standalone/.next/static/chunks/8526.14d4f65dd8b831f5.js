"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8526,1833],{81249:(e,t,n)=>{n.r(t),n.d(t,{default:()=>i});var r=n(90016),l=n(66666),s=n(13977),a=n(98414);function i(){let[e,t]=(0,l.useState)(""),[n,i]=(0,l.useState)(!1),o=(0,l.useRef)(),u=()=>{o.current&&window.clearTimeout(o.current)},d=(e,t)=>{u();let n=window.setTimeout(e,t);o.current=n};return(0,r.jsx)(s.ChatForm,{className:"w-full max-w-[500px]",isPending:!1,handleSubmit:e=>{var n;null==e||null===(n=e.preventDefault)||void 0===n||n.call(e),t(""),i(!0),d(()=>{i(!1)},2e3)},children:(0,r.jsx)(a.MessageInput,{value:e,onChange:e=>{t(e.target.value)},stop:()=>{i(!1),u()},isGenerating:n})})}},78743:(e,t,n)=>{n.d(t,{M:()=>x});var r=n(90016),l=n(66666),s=n(50784),a=n(2851),i=n(32591);class o extends l.Component{getSnapshotBeforeUpdate(e){let t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){let e=this.props.sizeRef.current;e.height=t.offsetHeight||0,e.width=t.offsetWidth||0,e.top=t.offsetTop,e.left=t.offsetLeft}return null}componentDidUpdate(){}render(){return this.props.children}}function u(e){let{children:t,isPresent:n}=e,s=(0,l.useId)(),a=(0,l.useRef)(null),u=(0,l.useRef)({width:0,height:0,top:0,left:0}),{nonce:d}=(0,l.useContext)(i._);return(0,l.useInsertionEffect)(()=>{let{width:e,height:t,top:r,left:l}=u.current;if(n||!a.current||!e||!t)return;a.current.dataset.motionPopId=s;let i=document.createElement("style");return d&&(i.nonce=d),document.head.appendChild(i),i.sheet&&i.sheet.insertRule('\n          [data-motion-pop-id="'.concat(s,'"] {\n            position: absolute !important;\n            width: ').concat(e,"px !important;\n            height: ").concat(t,"px !important;\n            top: ").concat(r,"px !important;\n            left: ").concat(l,"px !important;\n          }\n        ")),()=>{document.head.removeChild(i)}},[n]),(0,r.jsx)(o,{isPresent:n,childRef:a,sizeRef:u,children:l.cloneElement(t,{ref:a})})}let d=e=>{let{children:t,initial:n,isPresent:i,onExitComplete:o,custom:d,presenceAffectsLayout:c,mode:p}=e,f=(0,a.h)(h),m=(0,l.useId)(),v=(0,l.useCallback)(e=>{for(let t of(f.set(e,!0),f.values()))if(!t)return;o&&o()},[f,o]),x=(0,l.useMemo)(()=>({id:m,initial:n,isPresent:i,custom:d,onExitComplete:v,register:e=>(f.set(e,!1),()=>f.delete(e))}),c?[Math.random(),v]:[i,v]);return(0,l.useMemo)(()=>{f.forEach((e,t)=>f.set(t,!1))},[i]),l.useEffect(()=>{i||f.size||!o||o()},[i]),"popLayout"===p&&(t=(0,r.jsx)(u,{isPresent:i,children:t})),(0,r.jsx)(s.O.Provider,{value:x,children:t})};function h(){return new Map}var c=n(77936),p=n(38771);let f=e=>e.key||"";function m(e){let t=[];return l.Children.forEach(e,e=>{(0,l.isValidElement)(e)&&t.push(e)}),t}var v=n(91935);let x=e=>{let{children:t,exitBeforeEnter:n,custom:s,initial:i=!0,onExitComplete:o,presenceAffectsLayout:u=!0,mode:h="sync"}=e;(0,p.k)(!n,"Replace exitBeforeEnter with mode='wait'");let x=(0,l.useMemo)(()=>m(t),[t]),w=x.map(f),g=(0,l.useRef)(!0),y=(0,l.useRef)(x),k=(0,a.h)(()=>new Map),[M,Z]=(0,l.useState)(x),[C,E]=(0,l.useState)(x);(0,v.L)(()=>{g.current=!1,y.current=x;for(let e=0;e<C.length;e++){let t=f(C[e]);w.includes(t)?k.delete(t):!0!==k.get(t)&&k.set(t,!1)}},[C,w.length,w.join("-")]);let R=[];if(x!==M){let e=[...x];for(let t=0;t<C.length;t++){let n=C[t],r=f(n);w.includes(r)||(e.splice(t,0,n),R.push(n))}"wait"===h&&R.length&&(e=R),E(m(e)),Z(x);return}let{forceRender:j}=(0,l.useContext)(c.p);return(0,r.jsx)(r.Fragment,{children:C.map(e=>{let t=f(e),n=x===C||w.includes(t);return(0,r.jsx)(d,{isPresent:n,initial:(!g.current||!!i)&&void 0,custom:n?void 0:s,presenceAffectsLayout:u,mode:h,onExitComplete:n?void 0:()=>{if(!k.has(t))return;k.set(t,!0);let e=!0;k.forEach(t=>{t||(e=!1)}),e&&(null==j||j(),E(y.current),o&&o())},children:e},t)})})}},13192:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ArrowDown",[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]])},16776:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ArrowUp",[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]])},79130:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Dot",[["circle",{cx:"12.1",cy:"12.1",r:"1",key:"18d7e5"}]])},41853:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("Square",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]])},3177:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ThumbsDown",[["path",{d:"M17 14V2",key:"8ymqnk"}],["path",{d:"M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z",key:"s6e0r"}]])},25006:(e,t,n)=>{n.d(t,{Z:()=>r});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(38861).Z)("ThumbsUp",[["path",{d:"M7 10v12",key:"1qc93n"}],["path",{d:"M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z",key:"y3tblf"}]])}}]);