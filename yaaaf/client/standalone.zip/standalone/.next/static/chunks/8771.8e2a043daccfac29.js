"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8771,6123,1273],{98949:(e,t,a)=>{a.r(t),a.d(t,{MessageList:()=>i});var s=a(1917),l=a(95771),n=a(1273);function i(e){let{messages:t,showTimeStamps:a=!0,isTyping:i=!1,messageOptions:r,onArtifactClick:d,streamStatus:c}=e;return(0,s.jsxs)("div",{className:"space-y-4 overflow-visible",children:[t.map((e,n)=>{let i="function"==typeof r?r(e):r,o="assistant"===e.role&&n===t.length-1,h=o&&(null==c?void 0:c.is_active);return(0,s.jsx)(l.ChatMessage,{showTimeStamp:a,...e,...i,onArtifactClick:d,streamStatus:h?c:void 0,isLastMessage:o},n)}),i&&(0,s.jsx)(n.TypingIndicator,{streamStatus:c})]})}},1273:(e,t,a)=>{a.r(t),a.d(t,{TypingIndicator:()=>n});var s=a(1917),l=a(40451);function n(e){let{streamStatus:t}=e;return(0,s.jsx)("div",{className:"justify-left flex space-x-1",children:(0,s.jsx)("div",{className:"rounded-lg bg-muted p-3",children:(0,s.jsxs)("div",{className:"flex items-center gap-2 text-muted-foreground",children:[(0,s.jsx)(l.Z,{className:"h-4 w-4 animate-spin"}),(0,s.jsx)("span",{className:"text-xs",children:(null==t?void 0:t.is_active)&&(null==t?void 0:t.current_agent)?"orchestrator"===t.current_agent?"Planning...":"Running ".concat(t.current_agent,"..."):"Thinking..."}),(null==t?void 0:t.is_active)&&(null==t?void 0:t.goal)&&(0,s.jsxs)("span",{className:"text-xs opacity-70",children:["•"," ",t.goal.length>50?t.goal.substring(0,50)+"...":t.goal]})]})})})}},94704:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]])},15480:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},45527:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},18576:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]])},40451:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},39636:(e,t,a)=>{a.d(t,{Z:()=>s});/**
 * @license lucide-react v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(88867).Z)("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]])}}]);